<script lang="ts" setup>
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
useHead({
  title: t('sponsors.title'),
  titleTemplate: '%s - Reden',
});

type Sponsor = {
  name: string;
  detail?: string;
  avatar: string;
  amount: number;
  unit: string;
  message?: string;
};

const unitDisplay: Record<string, string> = {
  CNY: '¥',
  USD: '$',
  EUR: '€',
  JPY: 'JP¥',
  KRW: '₩',
  GBP: '£',
  CAD: 'C$',
  AUD: 'A$',
  HKD: 'HK$',
};

const { data: sponsors } = await useFetch<Sponsor[], ErrorResponse>(
  `/api/sponsors`,
);
const sorted = computed(
  () =>
    sponsors.value?.sort((a: Sponsor, b: Sponsor) => {
      return b.amount - a.amount;
    }) ?? [],
);
</script>

<template>
  <div>
    <h1 class="text-center">
      {{ $t('sponsors.title') }}
    </h1>
    <p class="text-center">
      {{ $t('sponsors.description') }}
    </p>
    <v-card border class="content-common">
      <v-list
        v-for="sponsor in sorted"
        :key="sponsor.name"
        link
        subheader
        three-line
      >
        <!--suppress VueUnrecognizedDirective -->
        <v-list-item :key="sponsor.name" v-ripple>
          <v-list-item-title class="text-h6"
            >{{ sponsor.name }}
          </v-list-item-title>
          <v-list-item-subtitle
            >{{ sponsor.detail || unitDisplay[sponsor.unit] + sponsor.amount }}
          </v-list-item-subtitle>
          <v-list-item-action>
            <v-img :src="sponsor.avatar" />
          </v-list-item-action>

          <div v-html="sponsor.message" />
        </v-list-item>
      </v-list>
    </v-card>
    <div class="text-center content-common pa-6">
      <p>
        {{ $t('sponsors.notice') }}
      </p>
      <p class="text-md-h5">
        {{ $t('sponsors.alipay') }}
        <br />
        <img :width="200" alt="" src="/image/reden-alipay.png" />
      </p>
      <a class="text-md-h5" href="https://paypal.me/zly2006">
        {{ $t('sponsors.paypal') }}
      </a>
    </div>
  </div>
</template>
