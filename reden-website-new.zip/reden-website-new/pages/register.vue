<script lang="ts" setup>
import { toast } from 'vuetify-sonner';
import { ref } from 'vue';
import CommonCaptcha from '@/components/CommonCaptcha.vue';
import {
  type Captcha,
  doFetchPost,
  isStrongPassword,
  resetCaptcha,
  toastError,
  usernameRegex,
} from '@/utils/constants';
import { useI18n } from 'vue-i18n';
import { type SubmitEventPromise } from 'vuetify';
import RedenRouter from '~/components/RedenRouter.vue';
import OAuthButtons from '~/components/misc/OAuthButtons.vue';

const email = ref('');
const username = ref('');
const password = ref('');
const confirmPassword = ref('');
const invitationCode = ref('');
const loading = ref(false);
const registerOk = ref(false);
const captcha = ref<Captcha>();
const { t } = useI18n();
const localePath = useLocalePath();
useHead({
  title: t('register.title'),
  titleTemplate: '%s - Reden',
});

function register(e: SubmitEventPromise) {
  e.preventDefault();
  e.then((e) => {
    if (!e.valid) return;
    loading.value = true;
    const req = {
      email: email.value,
      username: username.value,
      password: password.value,
      invitationCode: invitationCode.value,
      timestamp: new Date().getTime(),
      captcha: captcha.value,
    };
    doFetchPost('/api/account/register/start', req)
      .then((res) => {
        if (res.ok) {
          toast.success(t('register.toast.successful.title'), {
            description: t('register.toast.successful.message'),
            duration: 1000,
          });
          registerOk.value = true;
        } else {
          resetCaptcha();
          return Promise.reject(res);
        }
      })
      .catch((e) => toastError(e, 'Failed to register'))
      .finally(() => {
        loading.value = false;
      });
  });
}
</script>

<template>
  <div class="main-page">
    <v-form v-if="!registerOk" class="register-form" @submit="register">
      <h2 class="mt-6">
        {{ t('register.quick') }}
      </h2>
      <span>
        {{ t('register.oauth_agree') }}
        <reden-router :to="localePath('/legal/privacy')">
          {{ t('common.privacy_policy') }}
        </reden-router>
      </span>

      <o-auth-buttons />
      <h1 class="mt-6">
        {{ t('register.title') }}
      </h1>
      <v-text-field
        v-model="email"
        :label="t('register.placeholder.email')"
        :placeholder="t('register.placeholder.email')"
        :rules="[() => /.+@.+\..+/i.test(email) || t('register.invalid.email')]"
        autocomplete="email"
        required
      >
        <template #prepend>
          <v-icon>mdi-email</v-icon>
        </template>
      </v-text-field>
      <v-text-field
        v-model="username"
        :label="t('register.placeholder.username')"
        :placeholder="t('register.placeholder.username')"
        :rules="[
          () => usernameRegex.test(username) || t('register.invalid.username'),
        ]"
        autocomplete="username"
        required
      >
        <template #prepend>
          <v-icon>mdi-account</v-icon>
        </template>
      </v-text-field>
      <v-text-field
        v-model="password"
        :label="t('register.placeholder.password')"
        :placeholder="t('register.placeholder.password')"
        :rules="[
          () =>
            isStrongPassword(password) ||
            t('register.invalid.password.strength'),
        ]"
        autocomplete="new-password"
        required
        type="password"
      >
        <template #prepend>
          <v-icon>mdi-lock</v-icon>
        </template>
      </v-text-field>
      <v-text-field
        v-model="confirmPassword"
        :label="t('register.placeholder.confirm')"
        :placeholder="t('register.placeholder.confirm')"
        :rules="[
          () =>
            confirmPassword == password ||
            t('register.invalid.password.mismatching'),
        ]"
        autocomplete="new-password"
        required
        type="password"
      >
        <template #prepend>
          <v-icon>mdi-lock</v-icon>
        </template>
      </v-text-field>
      <common-captcha v-model="captcha" />
      <v-text-field
        v-model="invitationCode"
        :label="t('register.placeholder.invitation_code')"
        :placeholder="t('register.placeholder.invitation_code')"
      />
      <span>
        {{ t('register.existing') }}
        <reden-router :to="localePath('/login')">{{
          t('register.login')
        }}</reden-router>
      </span>
      <reden-router :to="localePath('/legal/privacy')">
        {{ t('common.privacy_policy') }}
      </reden-router>
      <v-btn
        :disabled="!captcha?.token"
        :loading="loading"
        color="primary"
        type="submit"
      >
        {{
          captcha?.token
            ? t('register.button.register')
            : t('register.button.captcha')
        }}
      </v-btn>
    </v-form>

    <div v-if="registerOk">
      <v-sheet
        class="ok-screen pa-4 text-center mx-auto"
        elevation="12"
        max-width="600"
        rounded="lg"
      >
        <v-icon
          class="mb-5"
          color="success"
          icon="mdi-check-circle"
          size="112"
        ></v-icon>

        <h2 class="text-h5 mb-6">
          {{ t('register.email_verification.title') }}
        </h2>
        <span>{{
          t('register.email_verification.message', { email: email })
        }}</span>

        <v-divider class="mb-4"></v-divider>

        <v-row>
          <v-spacer />
          <v-btn
            :to="localePath('/')"
            class="text-none"
            color="success"
            rounded
            variant="flat"
            width="90"
          >
            {{ t('register.button.done') }}
          </v-btn>
        </v-row>
      </v-sheet>
    </div>
  </div>
</template>

<style scoped>
.register-form {
  display: flex;
  flex-direction: column;
  width: min(90%, 400px);
  left: 50%;
}

.main-page {
  display: flex;
  justify-content: center;
  align-content: center;
}

.ok-screen {
  margin-bottom: 100px;
  margin-top: 100px;
}
</style>
